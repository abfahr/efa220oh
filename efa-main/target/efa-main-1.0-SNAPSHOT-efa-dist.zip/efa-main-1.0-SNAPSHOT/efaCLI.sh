#!/bin/sh

`dirname $0`/runefa.sh de.nmichael.efa.cli.Main "$@"