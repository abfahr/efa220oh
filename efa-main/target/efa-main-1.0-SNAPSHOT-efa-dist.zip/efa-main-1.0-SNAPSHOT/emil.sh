#!/bin/sh

`dirname $0`/runefa.sh de.nmichael.efa.emil.Main $*
